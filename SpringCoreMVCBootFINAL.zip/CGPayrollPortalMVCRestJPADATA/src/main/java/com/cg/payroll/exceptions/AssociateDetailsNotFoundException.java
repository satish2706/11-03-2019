package com.cg.payroll.exceptions;

public class AssociateDetailsNotFoundException extends Exception {

	public AssociateDetailsNotFoundException(String message) {
		super(message);
	}


}
