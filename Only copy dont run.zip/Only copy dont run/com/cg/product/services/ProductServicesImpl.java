package com.cg.product.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.product.beans.Product;
import com.cg.product.daoservices.ProductDAO;
import com.cg.product.exception.ProductDetailsNotFoundException;

@Component("productService")
public class ProductServicesImpl implements ProductService{
	@Autowired
	private ProductDAO productDAO;

	@Override
	public Product acceptProductDetails(Product product) {
		product=productDAO.save(product);
		return product;
	}

	@Override
	public Product getProductDetails(int id) throws ProductDetailsNotFoundException {
		
		return productDAO.findById(id).orElseThrow(()->  new ProductDetailsNotFoundException("Product Not Available with this Id:-"+id)) ;
	}

	@Override
	public List<Product> getAllProducts() {

		return productDAO.findAll();
	}

	@Override
	public boolean removeProductDetails(int id) throws ProductDetailsNotFoundException {
		productDAO.delete(getProductDetails(id));
		return true;
	}

	@Override
	public Product updateProductDetails(int id, Product product) throws ProductDetailsNotFoundException {
		product.setId(id);
		product.setModel(product.getModel());
		product.setName(product.getName());
		product.setPrice(product.getPrice());
		//product=getProductDetails(id);
		return productDAO.save(product);
	}

}