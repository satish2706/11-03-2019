package com.cg.product.services;

import java.util.List;


import com.cg.product.beans.Product;
import com.cg.product.exception.ProductDetailsNotFoundException;

public interface ProductService {
Product acceptProductDetails(Product product);

Product getProductDetails(int id)  throws ProductDetailsNotFoundException;

List<Product> getAllProducts();

boolean removeProductDetails(int id)  throws ProductDetailsNotFoundException;

Product updateProductDetails(int id,Product product) throws ProductDetailsNotFoundException;

}
