package com.cg.product.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity																		//This is Used To create the table in The Database using Hibernate
public class Product {
	@Id											//This is used to make the id As primary Key  here i Have used primary key as Integer as a good practice
													//Here It does not mean we cannot make string as a primary key
													//Using org.hibernate.id.Assigned and it also means that you have to assign the ID value before saving the data.
	@GeneratedValue(strategy=GenerationType.AUTO)//Increment of Id automatically by 1 starting from 1
	private int id;
	private String name;
	private String model;
	private int price;


//Constructor with Id to find the details
	public Product(int id, String name, String model, int price) {
		super();
		this.id = id;
		this.name = name;
		this.model = model;
		this.price = price;
	}


	//Constructor without Id to generate the id
	public Product(String name, String model, int price) {
		super();
		this.name = name;
		this.model = model;
		this.price = price;
	}


//below are the getters and setters
	public Product() {

	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getModel() {
		return model;
	}



	public void setModel(String model) {
		this.model = model;
	}



	public int getPrice() {
		return price;
	}



	public void setPrice(int price) {
		this.price = price;
	}



	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", model=" + model + ", price=" + price + "]";
	}



}
