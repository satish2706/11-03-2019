package com.cg.product.exception;

public class ProductDetailsNotFoundException extends Exception {

	public ProductDetailsNotFoundException(String Message) {
		super(Message);
		// TODO Auto-generated constructor stub
	}


	
}
